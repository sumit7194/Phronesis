#!/bin/bash
cd /home/sumit/ph_run
exec venv/bin/python steer_ih_32b_v2_vm.py \
  --alpha-fracs=-0.2,0,0.05,0.1,0.15,0.2,0.3 \
  --out ih_32b_v3.json --status status_steer.json
